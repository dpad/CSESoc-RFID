#include <io.h>
#include <signal.h>
#include <iomacros.h>
#include <string.h>

#include "serial.h"
#include "spi.h"
#include "led.h"
#include "timer.h"
#include "trf796x.h"
#include "iso14443.h"
/**************************************************
 * IRQ handling
 */

static volatile int irq_recv = 0;

void irq_wait(void)
{
	while (!irq_recv)
		; // go to sleep?
}

void irq_reset(void)
{
	irq_recv = 0;
}

int irq_is_pending(void)
{
	return irq_recv;
}

interrupt(PORT2_VECTOR) static irqhandler(void)
{
	uint8_t irqflags;

	irq_recv = 1;

	//printf("Got an IRQ!\n");

	// ack the interrupt
	irqflags = P2IFG;
	P2IFG = irqflags & ~RFID_IRQ;
}

void panic(void)
{
	led_ylw(0);
	led_red(1);

	for (;;) {
		led_ylw_toggle();
		led_red_toggle();
		delay(100000);
	}
}

