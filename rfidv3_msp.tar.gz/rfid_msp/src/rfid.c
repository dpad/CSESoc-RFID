#include <io.h>
#include <signal.h>
#include <iomacros.h>
#include <string.h>

#include "serial.h"
#include "spi.h"
#include "led.h"
#include "timer.h"
#include "trf796x.h"
#include "iso14443.h"
#include "bitbanged_spi.h"

void init_ports(void)
{
	P1OUT = 0x00;
	P1SEL = 0x00;
	P1DIR = LED_YLW | LED_RED;
	P1IES = 0x00;
	P1IE  = 0x00; 
	P1IFG = 0x00;
    

	P2SEL = 0x00;
	P2DIR = OMAP_IRQ_LINE;
	P2OUT = OMAP_IRQ_LINE; // this line is active low
	P2IES = 0x00;
	P2IE  = RFID_IRQ;
    P2IFG = 0x00;
    

	P3SEL = UART0_TX | UART0_RX;
	P3DIR = BB_DCLK_LINE;

	P4OUT = 0x00;
	P4SEL = 0x00;
	P4DIR = 0x00;

	P5OUT = RFID_SSEL;
	P5SEL = MISO1 | MOSI1 | DCLK1;
	P5DIR = RFID_SSEL;
	P5REN = 0x00;

	P6OUT = 0x00; 
	P6DIR = 0x00;
	P6SEL = 0x00;

}

#if 0
void init_clock(void)
{
	/*
	 * MCLK and SMCLK sourced from internal DCO at 16 MHz.  ACLK sourced from
	 * external 32.768 kHz crystal (12.5pF load C).
	 */

	DCOCTL = CALDCO_16MHZ;
	BCSCTL1 = (CALBC1_16MHZ | XT2OFF) & ~XTS;
	BCSCTL2 = SELM_DCOCLK | DIVM_DIV1 | DIVS_DIV1;
	BCSCTL3 = LFXT1S_0 | XCAP_3;
}
#endif

/**************************************************
 * IRQ handling
 */

static volatile int irq_recv = 0;

void irq_wait(void)
{
	while (!irq_recv)
		; // go to sleep?
}

void irq_reset(void)
{
	irq_recv = 0;
}

int irq_is_pending(void)
{
    
	return irq_recv;
    //P2OUT = 0;
    //P2IFG = 0;
    //return 1;
    //look at the pin connected to the TRF's irq line
    //return !(P2IN & BIT(0));
}

interrupt(PORT2_VECTOR) static irqhandler(void)
{
	uint8_t irqflags;

	irq_recv = 1;

	//printf("Got an IRQ!\n");
	

    // ack the interrupt
	irqflags = P2IFG;
	P2IFG = irqflags & ~RFID_IRQ;
}



/*************************************************/

#if 0
void sleep_ms(uint32_t ms)
{
	uint32_t timer = get_timer();

	while (get_timer() < timer + ms)
		;
}

void bitcp(uint8_t *dest, uint8_t *src, unsigned nbits)
{
	int i;
	unsigned nbytes = nbits / 8;
	unsigned xbits = nbits % 8;

	for (i=0; i < nbytes; i++) {
		dest[i] = src[i];
	}

	if (xbits) {
		uint8_t mask = ~(0x1 << xbits);
		dest[i] = src[i] & ~mask;
	}
}

static uint8_t encode_len(unsigned len)
{
	unsigned bytes = (len / 8) + 2;
	unsigned bits = (len % 8);
	return (bytes << 4) | bits;
}

static int ac_loop(unsigned cascade, uint8_t uid_out[ISO14443_UID_MAXLEN])
{
	uint8_t cmd[128];
	uint8_t buf[128];
	int ret;
	int i;

	unsigned len = 0; // current UID length

	while (len < 5*8) {
		//printf("cascade%d\n", cascade);

		cmd[0] = ISO14443A_CASCADE1;
		cmd[1] = encode_len(len);
		// cp in UID

		ret = trf796x_txrx(cmd, 2*8 + len, buf, 128, 0);
		if (ret != 5 || !iso14443_uid_crc(buf))
			continue;

		for (i=0; i<ret; i++) {
			uid_out[i] = buf[i];
		}

		break;
	}

	return 0;
}
#endif

#if 0

int main0(void)
{
	dint();

	init_ports();
	init_clock();
	time_init();
	uart0_init(UART_BAUD, SMCLK_FREQ);
	spi0_init();

	led_ylw(0);

	eint();

    printf("============================== START ==========================\n");
/*    for(;;){
        volatile uint32_t i = 0;
        for (i = 0; i < 100000; i++){
            ;
        }
        led_ylw_toggle();
    }
    */


#if 0
	trf796x_init();
	trf796x_iso14443a_init();
	trf796x_enable_radio();

	for (;;) {
		uint8_t reg;

		led_ylw(1);
		time_sleep_ms(500);

		reg = trf796x_read_reg(TRF796x_REG_STATUS);
		printf("ISOCTRL: 0x%02x\n", (unsigned)reg);

		time_sleep_ms(500);
	}
#endif

#if 0
	led_ylw(1);
	for (;;) {
		led_ylw_toggle();
		printf("a\n");
		time_sleep_us(500000);
	}
#endif

	trf796x_init();
	trf796x_iso14443a_init();

#if 0
	for (;;) {
		uint8_t reg;

		trf796x_write_reg(TRF796x_REG_MODULATOR, 0x31);
		time_sleep_us(30);
		(void)trf796x_read_reg(TRF796x_REG_MODULATOR);
#endif

#if 0
		uint8_t data = trf796x_read_reg(TRF796x_REG_STATUS);
		data |= BIT(5);
		trf796x_write_reg(TRF796x_REG_STATUS, data);

		time_sleep_s(2);
		led_ylw_toggle();

		data = trf796x_read_reg(TRF796x_REG_STATUS);
		data &= ~BIT(5);
		trf796x_write_reg(TRF796x_REG_STATUS, data);

		trf796x_enable_radio();
		reg = trf796x_read_reg(TRF796x_REG_STATUS);
		printf("EN: status: 0x%02x\n", (unsigned)reg);

		time_sleep_s(2);
		led_ylw_toggle();

		trf796x_disable_radio();
		reg = trf796x_read_reg(TRF796x_REG_STATUS);
		printf("DE: status: 0x%02x\n", (unsigned)reg);

		time_sleep_s(2);
		led_ylw_toggle();
	}

	trf796x_init();
#endif

//	trf796x_block_recvr();

	trf796x_enable_radio();
	printf("**** start ****\n");

	uint8_t buf[128];
	//uint8_t uid[ISO14443_UID_MAXLEN];
	//int i;
    //
    /*for(;;){
        printf("status = 0x%x\n", trf796x_read_reg(TRF796x_REG_STATUS));
        printf("isoctrl = 0x%x\n", trf796x_read_reg(TRF796x_REG_ISOCTRL));
    }*/

    int n = 0;
    for(;;){

		printf("\n\n---- reqa ----\n");

        int n = trf796x_readCard(buf, 128);
        printf("txrx returns: %d\n", n);


#if 0
		// sanity-check the response
		if (!(buf[0] == 0x04 && buf[1] == 0x00))
			continue;


#if 0
		ret = ac_loop(0, uid);
		for (i=0; i<5; i++) {
			cmd[2+i] = uid[i];
			printf("%02X\n", uid[i]);
		}
#else
		cmd[2] = 0xCC;
		cmd[3] = 0x82;
		cmd[4] = 0x09;
		cmd[5] = 0xC1;
		cmd[6] = 0x86;
#endif

		//printf("select\n");
		cmd[0] = ISO14443A_CASCADE1;
		cmd[1] = 0x70;
		// memcpy(&cmd[2], &uid[0], 5);
		ret = trf796x_txrx(cmd, 7*8, buf, 128, TRF796x_TXRX_TXCRC|TRF796x_TXRX_RXCRC|TRF796x_TXRX_NORETRY);
		if (ret != 1)
			continue;

		if ((buf[0] & ISO14443A_SAK_CASCADE))
			continue;

//		do {
			cmd[0] = 0x60;
			cmd[1] = 0x00;

			//printf("auth\n");
			//timerB_wait();

			ret = trf796x_txrx(cmd, 2*8, buf, 128, TRF796x_TXRX_TXCRC|TRF796x_TXRX_RXCRC|TRF796x_TXRX_NORETRY);
			if (ret < 0)
				continue;

			printf("auth resp: 0x");
			for (i=0; i<ret; i++) {
				printf("%02X", buf[i]);
			}
			printf("\n");

//		} while (0);
#endif
	}
}

#endif

uint8_t checksum_correct(uint8_t * uid) {
    return uid[0] == (uid[1] ^ uid[2] ^ uid[3] ^ uid[4]);
}

void rfid_loop(void) {

    uint8_t buf[5];

    //int uid[ISO14443_UID_MAXLEN];
    
    trf796x_init();
	trf796x_iso14443a_init();

    led_ylw(0);
    led_red(0);
        
    int j = 0;
    
    for (;;) {

 	    //reset the radio
        delay(100000);
        trf796x_enable_radio();

        /* ---- testing code ------ */

        trf796x_readCards();

        printf("---\n");
        
        while (trf796x_getNextUID(buf)) {
            if (checksum_correct(buf)) {
                led_red(1);
                printf("UID: ");
                for (j=0;j<5;j++) {
                    printf("%02x",buf[j]);
                }
                printf("\n");
            } else {
                led_ylw(1);
            }
        }

        delay(5000);
        led_red(0);
        led_ylw(0);
        
        P3OUT |= BB_DCLK_LINE;
        delay(50);
        P3OUT &= ~BB_DCLK_LINE;  
        
        trf796x_init();
        trf796x_iso14443a_init();

        /* ----- end testing code --- */
#if 0
        
        int n = trf796x_readCard(buf, 128); //this function has been removed

        //printf("txrx returns: %d\n\n\n", n);

        
        if (n == RFID_LENGTH){
            
            int i;
            // print the UID and reset buffer
            for (i = 0; i < n; i++){
                uid[i] = buf[i];
                //printf("%02x", uid[i]);
                buf[i] = 0;
            }
            //printf("\n");

            //printf("\n\n\nRead Card!\n\n\n");
            // Check the card ID was valid
            //int valid = trf796x_valid_card(uid);
            int valid= 1;
            if (!valid){
                //printf("--- ERROR! INVALID ID ---\n");
                //The trf has been reset, so re-initialize it.
                trf796x_init();
                trf796x_iso14443a_init();
                continue;
            }


            //interrupt the omap
            P2OUT &= ~BIT(4);
            

            //send the size of the UID
            n = 12;
//            spi_transfer_bitbang(NULL, n, 0, 0);
            //printf("n=%d\n", n);
            
/*
            //send the UID
            for (i=0;i<n;i++) {
                spi_transfer_bitbang(NULL, uid[i], 1, 1);
            }
*/            
            P2OUT |= BIT(4);
            
            //The trf has been reset, so re-initialize it.
            trf796x_init();
            trf796x_iso14443a_init();
            
        }
#endif

    }
}


void panic(void)
{
	led_ylw(0);
	led_red(1);

	for (;;) {
		led_ylw_toggle();
		led_red_toggle();
		delay(100000);
	}
}

