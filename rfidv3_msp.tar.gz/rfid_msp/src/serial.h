#include "printf.h"

void uart0_init(uint32_t baud, uint32_t clock);
void uart0_write(uint8_t data);
uint8_t uart0_read(void);
void init_clock(void);

