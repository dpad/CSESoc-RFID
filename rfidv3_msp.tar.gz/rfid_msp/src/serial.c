#include <stdlib.h>
#include <iomacros.h>
#include <signal.h>
#include <msp430x24x.h>

#include "rfid_panic.h"
#include "serial.h"

struct {
	uint32_t baud;
	uint32_t clk;
	uint8_t br0;
	uint8_t br1;
	uint8_t mctl;
} baud_table[] = {
	{ 115200, 16000000, 0x8a, 0x00, 0x40 },
	{ 0 },
};

static void uart0_set_baud(uint32_t baud, uint32_t clk_freq)
{
	int i;
    

	for (i=0; baud_table[i].baud; i++) {
		if ((baud_table[i].baud == baud) && (baud_table[i].clk == clk_freq)) {
			UCA0BR0 = baud_table[i].br0;
			UCA0BR1 = baud_table[i].br1;
			UCA0MCTL = baud_table[i].mctl;
			return;
		}
	}

	/* no valid baud/freq found */
	panic();
}

/* putc function for printf */
static void uart0_putc(void *p, char c)
{
	(void)p;
	uart0_write(c);

	if (c == '\n')
		uart0_write('\r');
}

void uart0_init(uint32_t baud, uint32_t clk_freq)
{
	/* 8n1, SMCLK, module disabled */
	UCA0CTL0 = 0x00;
	UCA0CTL1 = UCSWRST | UCSSEL_SMCLK;

	uart0_set_baud(baud, clk_freq); 

	/* no interrupts */
	IE2 &= ~(UCA0TXIE | UCA0RXIE);

	/* enable the uart */
	UCA0CTL1 &= ~UCSWRST;
 
	init_printf(NULL, &uart0_putc);
}

void uart0_write(uint8_t data)
{
	while ((IFG2 & UCA0TXIFG) == 0)
		;

	UCA0TXBUF = data;
}


#if 0
uint8_t uart0_read(void)
{
	for (;;) {
		if (U0RCTL & RXERR) {
			U0RCTL &= ~(FE | PE | OE | BRK | RXERR); 
		} else if (IFG1 & URXIFG0) {
			return U0RXBUF;
		}
	}
}
#endif

int clock_on = 0;
void init_clock(void)
{
    if (clock_on) return;
    clock_on = 1;
	
    /*
	 * MCLK and SMCLK sourced from internal DCO at 16 MHz.  ACLK sourced from
	 * external 32.768 kHz crystal (12.5pF load C).
	 */
	DCOCTL = CALDCO_16MHZ;
	BCSCTL1 = (CALBC1_16MHZ | XT2OFF) & ~XTS;
	BCSCTL2 = SELM_DCOCLK | DIVM_DIV1 | DIVS_DIV1;
	BCSCTL3 = LFXT1S_0 | XCAP_3;
}


