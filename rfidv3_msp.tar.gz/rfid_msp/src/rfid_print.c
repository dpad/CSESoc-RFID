#include <io.h>
#include <signal.h>
#include <iomacros.h>
#include <string.h>

#include "serial.h"
#include "rfid.h"

void rfid_print_init(void) {

    init_clock();
    
    // configure ports
    P3OUT = 0x00;
	P3SEL = UART0_TX | UART0_RX;
	P3DIR = 0x00;
    
	uart0_init(UART_BAUD, SMCLK_FREQ);
}
