#ifndef _ISO14443_H
#define _ISO14443_H

#include <stdint.h>

enum iso14443_limits {
	ISO14443_UID_MAXLEN = 17,
};

enum iso14443_cmds {
    ISO14443_REQA       = 0x26,
	ISO14443A_CASCADE1  = 0x93,
	ISO14443A_CASCADE2  = 0x95,
	ISO14443A_CASCADE3  = 0x97,
	ISO14443_CRCA_IV    = 0x6363,
    ISO14443_VALIDBYTES = 0x20,
};

enum iso14443_sak_bits {
	ISO14443A_SAK_CASCADE   = 0x01 << 2,
	ISO14443A_SAK_COMPLIANT = 0x01 << 5,
};

int iso14443_uid_crc(uint8_t buf[5]);
void iso14443_crcA(uint8_t *buf, unsigned buflen, uint8_t ret[2]);

#endif /* _ISO14443_H */

