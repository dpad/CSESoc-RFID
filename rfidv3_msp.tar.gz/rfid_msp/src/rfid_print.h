void rfid_print_init(void);
