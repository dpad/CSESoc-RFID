
#define BB_DCLK_LO !(P3IN & BIT(1))
#define BB_DCLK_HI P3IN & BIT(1)

#define BB_MOSI P2IN & BIT(3)

#define BB_SSEL_HI P2IN & BIT(2)
#define BB_SSEL_LO !(P2IN & BIT(2))

#define BB_MISO_SET P3OUT |= BIT(0)
#define BB_MISO_CLEAR P3OUT &= ~BIT(0)


void spi_transfer_bitbang(uint8_t * dest, uint8_t source, uint8_t pre_wait, uint8_t post_wait);
void bb_spi_write(uint8_t tx_data);
