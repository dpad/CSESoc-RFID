#include <io.h>
#include <signal.h>
#include <iomacros.h>

#include "rfid.h"
#include "led.h"

void led_ylw(int on)
{
	if (!on)
		LED_PORT |= LED_YLW;
	else
		LED_PORT &= ~LED_YLW;	
}
 
void led_ylw_toggle(void)
{
	LED_PORT ^= LED_YLW;
}

void led_red(int on)
{
	if (!on)
		LED_PORT |= LED_RED;
	else
		LED_PORT &= ~LED_RED;	
}
 
void led_red_toggle(void)
{
	LED_PORT ^= LED_RED;
}

