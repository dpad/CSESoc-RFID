#ifndef __LED__
#define __LED__
 
#include <io.h>
#include <signal.h>
#include <iomacros.h>

void led_ylw(int on);
void led_ylw_toggle(void);
void led_red(int on);
void led_red_toggle(void);

#endif /* __LED__ */ 
