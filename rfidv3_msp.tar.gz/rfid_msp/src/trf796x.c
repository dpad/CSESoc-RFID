#include <signal.h>
#include <stdlib.h>
#include "led.h"
#include "spi.h"
#include "trf796x.h"
#include "rfid.h"
#include "printf.h"
#include "iso14443.h"
#include "timer.h"

static void trf796x_reset(void);

typedef struct u_id * U_id;
typedef struct uidLink * UIDLink;
typedef struct uidStack * UIDStack;

UIDStack uidstack = NULL;

struct uidLink {
    U_id data;
    UIDLink next;
};

struct uidStack {
    UIDLink first;
    int size;
};

struct u_id {
    uint8_t array[5];
};

U_id new_U_id(void) {
    return malloc(sizeof(struct u_id));
}

UIDStack get_UIDStack(void) {
    if (uidstack == NULL){
        uidstack = malloc(sizeof(struct uidStack));
        uidstack->size = 0;
    }
    return uidstack;
}

void push_UIDStack(UIDStack this, U_id data) { 
    UIDLink newLink = malloc(sizeof(struct uidLink));
    newLink->data = data;
    newLink->next = this->first;
    this->first = newLink;
    this->size++;
}

U_id pop_UIDStack(UIDStack this) {
    U_id data = this->first->data;

    UIDLink prev = this->first;

    this->first = this->first->next;
    this->size--;

    free(prev);

    return data;
}


UIDStack uidBuffer;

int trf796x_init(void)
{
	trf796x_command(TRF796x_CMD_SWINIT);
	trf796x_reset();

    //printf("\n\nSTATUS: 0x%x\n", trf796x_read_reg(TRF796x_REG_STATUS));

    uidBuffer = get_UIDStack();

	return 0;
}

void trf796x_command(uint8_t cmd)
{
	//cmd &= TRF796x_ADDRESS_MASK;

	spi0_select_device(DEV_TRF796x);
	spi0_write(TRF796x_COMMAND | cmd);
	spi0_write(0x00); // dummy write, see SPI errata
	delay(15);
	spi0_deselect();
}

uint8_t trf796x_read_irqstatus(void)
{
	uint8_t value;

	spi0_select_device(DEV_TRF796x);
	spi0_write(TRF796x_READ | TRF796x_CONT | TRF796x_ADDRESS | TRF796x_REG_IRQ_STATUS);
	value = spi0_read();
	(void)spi0_read();  // dummy read, required to clear status bits
	delay(15);
	spi0_deselect();

    if (irq_is_pending()){
        irq_reset();
    }

	return value;
}

uint8_t my_trf796x_read_irqstatus(void)
{
	uint8_t value;

	spi0_select_device(DEV_TRF796x);
	spi0_write(TRF796x_READ | TRF796x_CONT | TRF796x_ADDRESS | TRF796x_REG_IRQ_STATUS);
	value = spi0_read();
	(void)spi0_read();  // dummy read, required to clear status bits
	delay(15);
	spi0_deselect();


	return value;
}


uint8_t trf796x_read_reg(uint8_t reg)
{
	uint8_t value;
	reg &= TRF796x_ADDRESS_MASK;

	spi0_select_device(DEV_TRF796x);
	spi0_write(TRF796x_READ | TRF796x_ADDRESS | reg);
	delay(15);
	value = spi0_read();
	delay(15);
	spi0_deselect();

	return value;
}




void trf796x_write_reg(uint8_t reg, uint8_t value)
{
	reg &= TRF796x_ADDRESS_MASK;

	spi0_select_device(DEV_TRF796x);

	spi0_write(TRF796x_WRITE | TRF796x_ADDRESS | reg);
	spi0_write(value);

	delay(15);
	spi0_deselect();
}

int trf796x_iso14443a_init(void)
{
	/* reset IRQ status */
	//(void)trf796x_read_irqstatus();

	/* select ISO mode */
	trf796x_write_reg(TRF796x_REG_ISOCTRL, 0x88);
    //printf("isoctrl = 0x%x\n", trf796x_read_reg(TRF796x_REG_ISOCTRL));

	/* 106 kbps, odd parity */
	trf796x_write_reg(TRF796x_REG_TX_HIGHRATE, 0x00);
    //printf("highrate = 0x%x\n", trf796x_read_reg(TRF796x_REG_TX_HIGHRATE));

	/* disable TX timer */
	trf796x_write_reg(TRF796x_REG_TXTIMER_H, 0x00);
    //printf("txtimer_h = 0x%x\n", trf796x_read_reg(TRF796x_REG_TXTIMER_H));
	trf796x_write_reg(TRF796x_REG_TXTIMER_L, 0x00);
    //printf("txtimer_l = 0x%x\n", trf796x_read_reg(TRF796x_REG_TXTIMER_L));

	/* 2.36us pulselen */
	trf796x_write_reg(TRF796x_REG_TX_PULSELEN, 0x20);
    //printf("tx_pulselen = 0x%x\n", trf796x_read_reg(TRF796x_REG_TX_PULSELEN));

	/* 962.8us response time */
	trf796x_write_reg(TRF796x_REG_RX_NORESPONSE, 0xFF);
    //printf("noresponse = 0x%x\n", trf796x_read_reg(TRF796x_REG_RX_NORESPONSE));

	/* 66us RX wait time, 0x07 */
	trf796x_write_reg(TRF796x_REG_RX_WAITTIME, 0x07);
    //printf("rx_waittime = 0x%x\n", trf796x_read_reg(TRF796x_REG_RX_WAITTIME));

	/* 100% ASK, sysclk disabled, prev 0x01, 0x31 */
	trf796x_write_reg(TRF796x_REG_MODULATOR, 0x31);
    //printf("modulator = 0x%x\n", trf796x_read_reg(TRF796x_REG_MODULATOR));

	/* 847kHz BPF (ISO14443A subcarrier) */
	trf796x_write_reg(TRF796x_REG_RX_SPECIAL, 0x20);
    //printf("rx_special = 0x%x\n", trf796x_read_reg(TRF796x_REG_RX_SPECIAL));

    /* Enable all IRQs */
    trf796x_write_reg(TRF796x_REG_IRQ_MASK, 0x3F);
    //printf("irq_mask = 0x%x\n", trf796x_read_reg(TRF796x_REG_IRQ_MASK));
    
    //printf("TRF796x RFID driver initialised\n");
	return 0;
}

int trf796x_set_radio(int state)
{
	uint8_t data = trf796x_read_reg(TRF796x_REG_STATUS);
	if (state)
		data |= BIT(5);
	else
		data &= ~BIT(5);
	trf796x_write_reg(TRF796x_REG_STATUS, data);

	return 0;
}

static int trf796x_irq_poll()
{
	uint8_t data;

	if (!irq_is_pending()) {
	   // printf(".\n");
        return -1;
    }

	dint();
    data = trf796x_read_irqstatus();
    //printf("irq status: 0x%x\n", data);
	irq_reset();
	eint();

	return data;
}

static int trf796x_irq_wait()
{
	int data;

    int tries = 0;

	//printf("Waiting for irq... ");

	do {
	    //printf("status: 0x%x\n", trf796x_read_reg(TRF796x_REG_STATUS));
        //irq_wait();
		data = trf796x_irq_poll();
        tries++;
	} while (data < 0 && tries < 100);

	//printf("done\n");

	return data;
}

static int __trf796x_tx(uint8_t *bytes, int nbits, uint8_t crc)
{
	int nbytes = nbits / 8;
	int xbits  = nbits % 8;


    // Reset FIFO
    trf796x_command(TRF796x_CMD_RESET);
/*
    int test[10];
    int size = trf796x_read_fifo(test, 2);
    int j;
    printf("fifo: ");
    for (j=0;j<size+2;j++) {
        printf("%d ", test[j]);
    }
*/    
    // Change CRC
    if (crc & TRF796x_TXCRC){
        (void)trf796x_command(TRF796x_CMD_XMIT_CRC);
    } else {
        (void)trf796x_command(TRF796x_CMD_XMIT_NOCRC);
    }


    spi0_select_device(DEV_TRF796x);

	spi0_write(TRF796x_WRITE | TRF796x_CONT | TRF796x_ADDRESS | TRF796x_REG_FIFO_TXLEN1);
	spi0_write((nbytes & 0xFF0) >> 4); // write upper 2 nibbles

	uint8_t data = (nbytes & 0x00F) << 4;
	if (xbits) {
		data |= (xbits << 1) | 0x01;
	}
	spi0_write(data); // write lower nibble & partial byte

	/* SPI errata: split the write into two halves */
	delay(15);
	spi0_deselect();

    
    delay(100);

	spi0_select_device(DEV_TRF796x);
	spi0_write(TRF796x_WRITE | TRF796x_CONT | TRF796x_ADDRESS | TRF796x_REG_FIFO_IO);

//	for (i=0; i<12; i++) {
//		spi0_write(bytes[i]);
//	}

	/* write the full bytes */
    int i;
	for (i=0; i < nbytes; i++) {
		spi0_write(bytes[i] & 0xFF);
	}

	/* write the partial byte if needed */
	if (xbits) {
		spi0_write(bytes[i++]);
	}

	// SPI errata
	if (nbits == 8)
		spi0_write(0x00);

	delay(15);
	spi0_deselect();

	return 0;
}

static int __trf796x_rx(uint8_t *bytes, unsigned nbytes, int more)
{
	uint8_t status;
	unsigned recvbytes;

	status = trf796x_read_reg(TRF796x_REG_FIFO_STATUS);
	recvbytes = status & 0x0F;
	recvbytes = trf796x_read_fifo(bytes, more);

	return recvbytes;
}

int trf796x_read_fifo(uint8_t *bytes, int more)
{
	int i;
    int nbytes;
    uint8_t status;

    status = trf796x_read_reg(TRF796x_REG_FIFO_STATUS);
    nbytes = (status & 0x0F) + 1;
    

	spi0_select_device(DEV_TRF796x);
    spi0_write(TRF796x_READ | TRF796x_CONT | TRF796x_ADDRESS | TRF796x_REG_FIFO_IO);
    
    for (i=0; i < nbytes; i++) {
 		bytes[i] = spi0_read();
	}
	spi0_deselect();
    

	return nbytes;
}

int trf796x_block_recvr(void)
{
	trf796x_command(TRF796x_CMD_RECVR_DISABLE);
	return 0;
}

int trf796x_enable_recvr(void)
{
	trf796x_command(TRF796x_CMD_RECVR_ENABLE);
	return 0;
}

/* reset state after xmit or recv to ensure no future surprises */
static void trf796x_reset(void)
{
	trf796x_block_recvr();
	trf796x_command(TRF796x_CMD_RESET); // drain FIFO
	(void)trf796x_read_irqstatus();     // clear IRQ status
	trf796x_enable_recvr();
}

uint16_t trf796x_read_collision_pos(void)
{
	uint8_t reg;
	uint16_t collpos;

	collpos = trf796x_read_reg(TRF796x_REG_COLLISION_POS);
	reg = trf796x_read_reg(TRF796x_REG_IRQ_MASK);
	collpos |= (reg & 0xC0) << 10;

	return collpos;
}

// wait until the timer runs out or an irq is received
int wait_for_irq(void) {
    int i=100;
    int fail=0;
    while(!irq_is_pending()) {
        if (i==0) {
            fail=1;
            break;
        }
        delay(500);
        i--;
    }

    if (fail) {
        return 0;
    } else {
        return 1;
    }

}

// When a card responds to search criteria it does not
// send back the components of its UID that were sent
// as search criteria. If the criteria ended in a broken
// byte (ie. the number of bits in the criteria mod 8 != 0)
// then the response's first byte will be missing the lower
// bits in positions of the ones that were sent (so that
// the offset of bits is maintained). This function merges
// two arrays with a specified number of valid bits for each with
// the assumption that the first array is a search criteria
// and the second array is a response. They are merged into a
// uid component which is either a complete UID or a search string
// combining an original search string with some more response bits.
void array_merge(uint8_t * dest, 
                 uint8_t * first, uint8_t * second, 
                 int first_bits, int second_bits) {
    
    int first_bytes = first_bits >> 3;
    int first_xbits = first_bits & 0x07;
    int second_bytes = second_bits >> 3;
    int second_xbits = second_bits & 0x07;
    
    
    int i;
    // copy the full bytes from first
    for (i=0;i<first_bytes;i++) {
        dest[i] = first[i];
    }

    // if the first has extra bits, copy them
    if (first_xbits) {



        // If there are n extra bits in the first array, the first
        // n bits of the second array can be ignored.

        // construct a mask for the extra bits
        uint8_t mask = 0;
        for (i=0;i<first_xbits;i++) {
            mask <<= 1;
            mask |= 1;
        }
        
        dest[first_bytes] = first[first_bytes] & mask;
        
        // Mask the lower bits of the first byte of the second array
        // and append the higher bits to the last byte of the first
        // array.
        dest[first_bytes] |= (second[0] & ~mask);//TODO: Test this line here
                                                 //It's commented out below but should be here.
        
        //if there were no full bytes in the second array then the
        //extra bytes were used up
        if (second_bytes == 0) {
            second_xbits = 0;
        } else {

            //dest[first_bytes] |= (second[0] & ~mask);       
            
            second_bytes--; // There is now 1 less byte in the second arraay
            second++;//this pointer is incremented to the next array element
            first_bytes++; // There is effectively 1 more byte in the first array
        }
    }

    //copy the rest of the second array
    for (i=0;i<second_bytes;i++) {
        dest[first_bytes + i] = second[i];
    }
    //copy any extra bits from the second array
    if (second_xbits) {
        dest[first_bytes+second_bytes] = second[second_bytes];
    }

}

// Sets the value of the bit-th bit in the given array to value
void array_bit_mod(uint8_t * array, int bit, int value) {
    int element = bit >> 3;
    int offset = bit & 0x07;
    if (value) {
        array[element] |= (1<<offset);
    } else {
        array[element] &= ~(1<<offset);
    }
}

//halts the selected card
void trf796x_halt(void) {
    uint8_t cmd[TRF796x_CMD_LIST_SIZE];

    cmd[0] = 0x50;
    cmd[1] = 0x00;

    __trf796x_tx(cmd, 16, TRF796x_TXCRC);
    wait_for_irq();
    trf796x_read_irqstatus();
    time_sleep_ms(1);
}

//selects a card by its uid
int trf796x_select(uint8_t * uid) {
    uint8_t cmd[TRF796x_CMD_LIST_SIZE];

    cmd[0] = ISO14443A_CASCADE1;
    cmd[1] = 0x70; //2 bytes for sel and nvb + 5 bytes for uid

    int i;
    for (i=0;i<5;i++) {
        cmd[2+i] = uid[i];
    }
    

    __trf796x_tx(cmd, 56, TRF796x_TXCRC);
    
    int irq_received = wait_for_irq();
    int irq_status = trf796x_read_irqstatus();


  //  printf("%x \n", irq_status);
    uint8_t buf[128];
    int rec_bytes = trf796x_read_fifo(buf, 0);

    
    if (irq_received &&
        (irq_status & TRF796x_TXSIG) && 
        (irq_status & TRF796x_RXSIG)) {
        
        int sak = buf[0];
        if (rec_bytes > 0 && (sak & BIT(3))) { //check that the uid is complete
            return sak;
        }

    }
    
    return 0;
}

// sends the REQA command to a card
// TODO: do something useful with the ATQA
void trf796x_reqa(void) {
    int i;
    uint8_t buf[128];
    uint8_t cmd[TRF796x_CMD_LIST_SIZE];
    uint8_t irq_status0, irq_status1;

    //send the reqa command
    cmd[0] = ISO14443_REQA;
    __trf796x_tx(cmd, 7, 0x00);

    //wait for the end of tx irq
    wait_for_irq();
    trf796x_read_irqstatus();
    
    //wait for the end of rx irq
    wait_for_irq();
    trf796x_read_irqstatus();

    // the ATQA is now in the FIFO
    // read the fifo (to clear it)
    trf796x_read_fifo(buf, 0);
    
}



void trf796x_anticollision(uint8_t sel, uint8_t * criteria, int crit_bits) {
    uint8_t buf[128];
    uint8_t cmd[TRF796x_CMD_LIST_SIZE];
    int valid_bits = 0; //the number of valid bits placed in buf
     
    int crit_bytes = crit_bits >> 3;
    int crit_xbits = crit_bits & 0x07;
    
    int nvb = 0x20 + (crit_bytes << 4) + crit_xbits;


    //the number of bits that will be sent making up the sel, nvb and uid_criteria
    //The upper 4 bits of the nvb are the number of bytes. Shifting these one place
    //to the right multiplies the byte count by 8 since it was already essentially
    //shifted 4 to the left (and shifting 3 to the left multiplies by 8).
    //The lower 4 bits of the nvb are the left-over bits, so these are added to
    //obtain the total.
    int bits = ((nvb & 0xf0) >> 1) + (nvb & 0x0f);
    
    cmd[0] = sel; //this specifies the cascade level
    cmd[1] = nvb; //number of valid bytes


    //copy the uid search criteria into the command buffer
    int i;
    for (i=0;i<crit_bytes;i++) {
        cmd[2+i] = criteria[i];    
    }

    //add on any extra bits
    if (crit_xbits != 0) {
        cmd[2+i] = criteria[i];
    }


    //transmit the commands
    __trf796x_tx(cmd, bits, 0x00);

    int irq_received = wait_for_irq();
    int irq_status = trf796x_read_irqstatus();
    
    //this delay is required
    time_sleep_ms(1);
    
    //now we can read the uid component from the fifo
    int rec_bytes = trf796x_read_fifo(buf, 0);
    
    if (irq_received &&
        (irq_status & TRF796x_TXSIG) && 
        (irq_status & TRF796x_RXSIG)) {
        
        if (irq_status & TRF796x_COLLISION) {
            // A collision has occured!

            // get the position of the collision (including
            // the bits in the sel and nvb)
            int coll_pos = trf796x_read_collision_pos();
            
            // subtract the number of bits from the sel and nvb
            valid_bits = coll_pos - 0x20;
            
            // these will hold the new search strings
            uint8_t new0[5];
            uint8_t new1[5];
            
            // populate the new seach strings by appending the bits that
            // were just read to the current search string
            array_merge(new0, criteria, buf, crit_bits, valid_bits);
            array_merge(new1, criteria, buf, crit_bits, valid_bits);
            
            // at this point the new search strings are identical

            // make sure one search string ends with a 0 and the other with
            // a 1
            array_bit_mod(new0, valid_bits, 0);
            array_bit_mod(new1, valid_bits, 1);

            // search for uids starting with both search strings
            trf796x_anticollision(ISO14443A_CASCADE1, new0, valid_bits+1);
            trf796x_anticollision(ISO14443A_CASCADE1, new1, valid_bits+1);

        } else {
            // no collision - we have the full uid

            // the valid bits of the uid component that was just read.
            // If there was more than one card then there will not be 
            // 40 valid bits. The size of the search string's byte offset
            // is subtracted from the number of bytes that were just read,
            // since that many low bits from the  first byte are to be 
            // discarded.
            valid_bits = (rec_bytes << 3) - (crit_bits & 0x07); 
            
            U_id uid = new_U_id();

            // merge the criteria with the uid component we just read
            array_merge(uid->array, criteria, buf, crit_bits, valid_bits);
            
            // add the new uid to the uid buffer
            push_UIDStack(uidBuffer, uid);
    
            // send a reqa 
            trf796x_reqa();  //TODO: move this line to the start of this function and test
                             //      also, remove the reqa from the function trf796x_readCards
        }
    


    }

}

// After UIDs have been read they are stored in a buffer.
// This function places a uid in the variable 'buf', removes
// it from the buffer and
// returns a 1 if the buffer is not empty. If the buffer
// is empty, the function returns a 0.
int trf796x_getNextUID(uint8_t * buf) {
    int i;
    
    if (uidBuffer->size == 0) {
        return 0;
    }

    U_id data = pop_UIDStack(uidBuffer);

    for (i=0;i<5;i++) {
        buf[i] = data->array[i];
    }

    free(data);

    return 1;
}

// frees up all memory allocated to uids in the uid buffer
void trf796x_clearUIDBuffer(void) {
    while (uidBuffer->size != 0) {
        free(pop_UIDStack(uidBuffer));
    }
}

void trf796x_readCards(void) {
    
    uint8_t criteria[5];

    //empty the uid buffer
    trf796x_clearUIDBuffer();

    //send out the reqa
    trf796x_reqa();

    //perform anticollision
    trf796x_anticollision(ISO14443A_CASCADE1, criteria, 0);


}




int trf796x_readCard(uint8_t *buf, int bufsz){



    uint8_t cmd[TRF796x_CMD_LIST_SIZE];
    int i;
    for (i = 0; i < TRF796x_CMD_LIST_SIZE; i++){
        cmd[i] = 0;
    }

    // ---------------------------
    // SHOULD BE DOING THE FOLLOWING TWO LINES
    // But weird shit starts to happen...

    // Turn off CRC
    //uint8_t crcReg = trf796x_read_reg(TRF796x_REG_ISOCTRL);
    //trf796x_write_reg(TRF796x_REG_ISOCTRL, crcReg | BIT(7));

    int ret = 0;
    int cascadeLevel = 0;
    int timeout = 0;
    int data = 0;

    // First command to send is the REQA
    cmd[0] = ISO14443_REQA;

    // Note that the REQA command is sent in 7 bytes, not 8 (errata)
    int outbits = 7;

    // Transmit commands out
xmit: 
    // ------------------------------------
    //
    // Debugging prints. Weird shit be happening here.
    //printf("isoctrl = 0x%x\n", trf796x_read_reg(TRF796x_REG_ISOCTRL));
    //printf("status = 0x%x\n", trf796x_read_reg(TRF796x_REG_STATUS));
    //printf("highrate = 0x%x\n", trf796x_read_reg(TRF796x_REG_TX_HIGHRATE));
    //printf("txtimer_h = 0x%x\n", trf796x_read_reg(TRF796x_REG_TXTIMER_H));
    //printf("txtimer_l = 0x%x\n", trf796x_read_reg(TRF796x_REG_TXTIMER_L));
//    printf("tx_pulselen = 0x%x\n", trf796x_read_reg(TRF796x_REG_TX_PULSELEN));
    //printf("noresponse = 0x%x\n", trf796x_read_reg(TRF796x_REG_RX_NORESPONSE));
 //   printf("rx_waittime = 0x%x\n", trf796x_read_reg(TRF796x_REG_RX_WAITTIME));
    //printf("modulator = 0x%x\n", trf796x_read_reg(TRF796x_REG_MODULATOR));
 //   printf("rx_special = 0x%x\n", trf796x_read_reg(TRF796x_REG_RX_SPECIAL));
    //printf("irq_mask = 0x%x\n", trf796x_read_reg(TRF796x_REG_IRQ_MASK));
    //printf("collision_pos = 0x%x\n", trf796x_read_reg(TRF796x_REG_COLLISION_POS));
    //printf("rssi_osc_status = 0x%x\n", trf796x_read_reg(TRF796x_REG_RSSI_OSC_STATUS));
    

    __trf796x_tx(cmd, outbits, 0x0);

    data = 0;
    timeout = 0;

    // Wait for an interrupt
wait:
    data = trf796x_irq_wait();
    //printf("Reading data... 0x%x (%d)\n", data, timeout);

    timeout++;

    if (timeout > 100){
        ret = RFID_ERR_TIMEOUT;
        goto out;
    } else if (data & TRF796x_NORESPONSE) {
        //printf("NO RESPONSE\n");
        ret = RFID_ERR_NORESPONSE;
        goto out;
    } else if (data & TRF796x_COLLISION) {
        //printf("COLLISION\n");
        ret = RFID_ERR_COLLISION;
        goto collision;
    } else if (data & (TRF796x_FRAMEERR|TRF796x_PARITYERR|TRF796x_CRCERR)){
        //printf("FRAMEERR\n");
        ret = RFID_ERR_FRAME;
        trf796x_reset();
        goto xmit;
    } else if (data & TRF796x_FIFOSIG) {
        //printf("FIFOSIG\n");
        ret = RFID_ERR_FIFO;
        trf796x_reset();
        goto xmit;
    } else if (data == TRF796x_TXSIG){
        //printf("TXSIG\n");
        goto wait;
    } else if (data == TRF796x_RXSIG){
        //printf("RXSIG\n");
        // Received data! Continue...
        ;
    } else if (data == (TRF796x_RXSIG|TRF796x_TXSIG)){
        //printf("TXSIG & RXSIG\n");
        // RX could still be in progress but assume completed RX
        ;
    } else {
        goto out;
    }

    // If we're here, then we received a response!
    // Read it from the FIFO
    ret = trf796x_read_fifo(buf, 0);
    //printf("(%d)\n", ret);
    trf796x_reset();

collision:

    switch(cascadeLevel){
        case 0:
            // If it was a collision, transmit again
            if (ret == RFID_ERR_COLLISION){
                //printf("Collisions: 0x%x\n", trf796x_read_reg(TRF796x_REG_COLLISION_POS));
                goto out;
            }
//goto skip;
            // If we didn't receive the correct response, quit out.
            // NICTA -> 0400, UNSW -> 0200
            if (!(buf[0] == 0x04 && buf[1] == 0x04) && !(buf[0] == 0x02 && buf[1] == 0x02)){
                //printf("WRONG DATA! Got %d bytes\n", ret);
                int i;
                for (i = 0; i < ret; i++){
                    //printf("0x%x ", buf[i]);
                }
                //printf("\n");
                ret = RFID_ERR_CASCADE0;
                goto out;
            }
//skip:
            // So good so far, clear the buffer and command list
            for (i = 0; i < TRF796x_CMD_LIST_SIZE; i++){
                cmd[i] = 0;
            }
            for (i = 0; i < bufsz; i++){
                buf[i] = 0;
            }

            // Now we transmit cascade level 1 to receive the UID
            int validBytes = ISO14443_VALIDBYTES;
            outbits = ((validBytes&0xF0)>>4)*8+(validBytes&0xF);

            // Commands to be transmitted
            cmd[0] = ISO14443A_CASCADE1;
            cmd[1] = validBytes;
            
            // Transmit the anti-collision command
            cascadeLevel = 1;
            goto xmit;

        case 1:
            // We should have received 5 bytes in the first cascade level
            if (ret != RFID_ERR_COLLISION){
                goto out;
            } else {
                //printf("Collisions: 0x%x\n", trf796x_read_reg(TRF796x_REG_COLLISION_POS));

                // TODO Perform anti-collision here.
            }
    }
    
out:
    trf796x_reset();

    return ret;
}

int trf796x_valid_card(int * uid) {
    return (uid[0] == (uid[1]^uid[2]^uid[3]^uid[4]));
}
