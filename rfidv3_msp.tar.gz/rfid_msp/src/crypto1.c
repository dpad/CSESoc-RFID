#include <string.h>
#include <stdint.h>

#include "crypto1.h"

#ifndef CHAR_BIT
#define CHAR_BIT 8
#endif

/* Clock the prng register by n steps and return the new state, don't
 * update the register. 
 * Note: returns a 32 bit value, even if the register is only 16 bit wide.
 * This return value is only valid, when the register was clocked at least
 * 16 times. */
static uint32_t prng_next(const crypto1_state * const state, const size_t n)
{
	uint32_t prng = state->prng;
	int i;

	/* The register is stored and returned in reverse bit order, this way, even
	 * if we cast the returned 32 bit value to a 16 bit value, the necessary
	 * state will be retained. */
	prng = rev32(prng);
	for (i = 0; i < n; i++) 
		prng = (prng<<1) | ( ((prng>>15)^(prng>>13)^(prng>>12)^(prng>>10)) & 1 );
	return rev32(prng);
}

/* == keystream generating filter function === */
/* This macro selects the four bits at offset a, b, c and d from the value x and returns the
 * concatenated bitstring  x_d || x_c || x_b || x_a  as an integer
 */
#define i4(x,a,b,c,d) ((uint32_t)(    \
		  bit(x, a)<<0 | bit(x, b)<<1 \
		| bit(x, c)<<2 | bit(x, d)<<3 \
	))

/* These macros are linearized boolean tables for the output filter functions. 
 * E.g. fa(0,1,0,1) is  (mf2_f4a >> 0x5)&1
 */
const uint32_t mf2_f4a = 0x9E98;
const uint32_t mf2_f4b = 0xB48E;
const uint32_t mf2_f5c = 0xEC57E80A;

/* Return one bit of non-linear filter function output for 48 bits of state input */
static uint32_t mf20 (const uint64_t x)
{
	const uint32_t d = 2;	/* number of cycles between when key stream is produced 
	                         * and when key stream is used.
							 * Irrelevant for software implmentations, but important
							 * to consider in side-channel attacks */

	const uint32_t i5 = ((mf2_f4b >> i4 (x, 7+d, 9+d,11+d,13+d)) & 1)<<0
                      | ((mf2_f4a >> i4 (x,15+d,17+d,19+d,21+d)) & 1)<<1
                      | ((mf2_f4a >> i4 (x,23+d,25+d,27+d,29+d)) & 1)<<2
                      | ((mf2_f4b >> i4 (x,31+d,33+d,35+d,37+d)) & 1)<<3
                      | ((mf2_f4a >> i4 (x,39+d,41+d,43+d,45+d)) & 1)<<4;	

	return (mf2_f5c >> i5) & 1;
}


/* == LFSR state update functions ============ */
/* Updates the 48-bit LFSR in state using the mifare taps, optionally
 * XORing in 1 bit of additional input, optionally XORing in 1 bit of 
 * cipher stream output (e.g. feeding back the output).
 * Return current cipher stream output bit. */
static uint8_t mifare_update (crypto1_state * const state, 
		const uint8_t injection, const uint8_t feedback)
{
	const uint64_t x = state->lfsr;
	const uint8_t ks = mf20(state->lfsr);
	
	uint64_t b = bit(x, 0) ^
	  bit(x, 5) ^
	  bit(x, 9) ^
	  bit(x, 10) ^
	  bit(x, 12) ^
	  bit(x, 14) ^
	  bit(x, 15) ^
	  bit(x, 17) ^
	  bit(x, 19) ^
	  bit(x, 24) ^
	  bit(x, 25) ^
	  bit(x, 27) ^
	  bit(x, 29) ^
	  bit(x, 35) ^
	  bit(x, 39) ^
	  bit(x, 41) ^
	  bit(x, 42) ^
	  bit(x, 43);
	b ^= injection ^ (feedback ? ks : 0);

	state->lfsr >>= 1;
	state->lfsr |= (b << 47);

	return ks;
}

/* Update the 48-bit LFSR in state using the mifare taps 8 times, optionally
 * XORing in 1 bit of additional input per step (LSBit first).
 * Return corresponding cipher stream. */ 
static uint8_t mifare_update_byte (crypto1_state * const state, 
		const uint8_t injection, const uint8_t feedback)
{
	uint8_t ret = 0;
	int i;
	for(i = 0; i < 8; i++)
		ret |= mifare_update(state, bit(injection, i), feedback) << i;
	return ret;
}

/* Update the 48-bit LFSR in state using the mifare taps 32 times, optionally
 * XORing in 1 byte of additional input per step (MSByte first).
 * Return the corresponding cipher stream. */
static uint32_t mifare_update_word (crypto1_state * const state, 
		const uint32_t injection, const uint8_t feedback)
{
	uint32_t ret = 0;
	int i;
	for(i = 3; i >= 0; i--)
		ret |= (uint32_t)mifare_update_byte(state, (injection >> (i*8)) & 0xff, feedback) << (i*8);
	return ret;
}

/*
 * Create a new cipher instance of either card or reader side
 */
int crypto1_new(crypto1_state *state, int is_card)
{
	state->is_card = is_card;
	return 0;
}

/*
 * Initialize a cipher instance with secret key
 */
void crypto1_init(crypto1_state *state, uint64_t key)
{
	state->lfsr = 0;
	state->prng = 0;

	/* Shift in keybytes in reverse order */
	int i;
	for (i=0; i<6; i++) {
		state->lfsr |= key & 0xFF;
		key >>= CHAR_BIT;
		state->lfsr <<= CHAR_BIT;
	}
}

/* 
 * First stage of mutual authentication given a card's UID.
 * card_challenge is the card nonce as an integer
 */
void crypto1_mutual_1(crypto1_state *state, uint32_t uid, uint32_t card_challenge)
{
 	const uint32_t IV = uid ^ card_challenge;
 	
	/* Go through the IV bytes in MSByte first, LSBit first order */
 	mifare_update_word(state, IV, 0);
 	
 	state->prng = card_challenge; /* Load the card's PRNG state into our PRNG */
 	return;
}

/*
 * Second stage of mutual authentication.
 * If this is the reader side, then the first 4 bytes of reader_response must
 * be preloaded with the reader nonce (and parity) and all 8 bytes will be
 * computed to be the correct reader response to the card challenge.
 * If this is the card side, then the response to the card challenge will be
 * checked.
 */
int crypto1_mutual_2(crypto1_state *state, parity_data_t *reader_response)
{
	if(state->is_card) {
		/* Reader challenge/Encrypted reader nonce */
		const uint32_t RC = ARRAY_TO_UINT32(reader_response);
		/* Encrypted reader response */
		const uint32_t RR_is = ARRAY_TO_UINT32(reader_response+4);

		/* Shift in reader challenge */
		const uint32_t keystream = mifare_update_word(state, RC, 1);
#ifdef PRINT_CORRECT_READER_CHALLENGE 
		printf("%016LX\n", RC ^ keystream);
#else
		(void)keystream;
#endif

		/* Generate expected reader response */
		const uint32_t RR_should = prng_next(state, 64) ^ mifare_update_word(state, 0, 0);

		return RR_should == RR_is;

	} else {

		/* Unencrypted reader nonce */
		const uint32_t reader_nonce = ARRAY_TO_UINT32(reader_response);
		int i;

		/* Feed the reader nonce into the state and simultaneously encrypt it */
		for(i = 3; i >= 0; i--) { /* Same as in mifare_update_word, but with added parity */
			reader_response[3-i] = reader_response[3-i] ^ mifare_update_byte(state, (reader_nonce >> (i*8)) & 0xff, 0);
			reader_response[3-i] ^= mf20(state->lfsr)<<8;
		}

		/* Unencrypted reader response */
		const uint32_t RR = prng_next(state, 64);
		UINT32_TO_ARRAY_WITH_PARITY(RR, reader_response+4);

		/* Encrypt the reader response */
		crypto1_transcrypt(state, reader_response+4, 4);
		return 0;
	}
}

/*
 * Third stage of mutual authentication.
 * If this is the reader side, then the card response to the reader
 * challenge will be checked.
 * If this is the card side, then the card response to the reader
 * challenge will be computed.
 */
int crypto1_mutual_3(crypto1_state *state, parity_data_t *card_response)
{
	if(state->is_card) {
		/* Unencrypted tag response */
		const uint32_t TR = prng_next(state, 96);
		UINT32_TO_ARRAY_WITH_PARITY(TR, card_response);

		/* Encrypt the response */
		crypto1_transcrypt(state, card_response, 4);
		return 0;
	} else {
		const uint32_t TR_is = ARRAY_TO_UINT32(card_response);
		const uint32_t TR_should = prng_next(state, 96) ^ mifare_update_word(state, 0, 0);

		return TR_is == TR_should;
	}
}

/*
 * Perform the Crypto-1 encryption or decryption operation on 'length' bytes
 * of data with associated parity bits.
 */
void crypto1_transcrypt(crypto1_state *state, parity_data_t *data, size_t length)
{
	crypto1_transcrypt_bits(state, data, length, 0);
}

/*
 * Perform the Crypto-1 encryption or decryption operation on 'bytes' bytes
 * of data with associated parity bits. 
 * The additional parameter 'bits' allows processing incomplete bytes after the
 * last byte. That is, if bits > 0 then data should contain (bytes+1) bytes where
 * the last byte is incomplete. 
 */
void crypto1_transcrypt_bits(crypto1_state *state, parity_data_t *data, size_t bytes, size_t bits)
{
	int i;

	for(i = 0; i< bytes; i++) {
		data[i] = data[i] ^ mifare_update_byte(state, 0, 0);
		data[i] = data[i] ^ (mf20(state->lfsr) << 8);
	}

	for(i = 0; i< bits; i++) {
		data[bytes] ^= mifare_update(state, 0, 0) << i;
	}
}

