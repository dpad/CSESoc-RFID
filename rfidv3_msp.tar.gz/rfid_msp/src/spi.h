#ifndef __SPI__
#define __SPI__

#include <io.h>
#include "rfid.h"

enum spi_devices {
	DEV_TRF796x,
	DEV_NONE
};

#define ENABLE_TRF796x() (RFID_PORT &= ~RFID_SSEL)
#define DISABLE_TRF796x() (RFID_PORT |= RFID_SSEL)

#define SPI_SELECT_RFID() spi0_select_device(DEV_TRF796x)
#define SPI_DESELECT_RFID() spi0_deselect()

void spi0_init(void);
void spi0_select_device(int device);
void spi0_deselect(void);
uint8_t spi0_transfer(uint8_t out_data);
uint8_t spi0_read(void);
void spi0_write(uint8_t out);

#endif
