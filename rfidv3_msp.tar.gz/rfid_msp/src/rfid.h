#ifndef _RFID_H
#define _RFID_H

#include <io.h>
#include <iomacros.h>

#ifndef CHAR_BIT
#define CHAR_BIT 8
#endif

/* Hardware definitions */
#define BIT(x) (0x1 << (x))

#define MCLK_FREQ 16000000
#define SMCLK_FREQ 16000000
#define ACLK_FREQ_LOG2 15
#define ACLK_FREQ (0x1 << ACLK_FREQ_LOG2)
#define UART_BAUD 115200

#define WDTCTL_INIT     (WDTPW|WDTHOLD)

static inline void delay(uint32_t x)
{
	uint32_t i;
	for (i=0; i<x; i++) {
		__asm__ ("nop");
	}
}

#define udelay(x) delay(x*16)

/* Port 1 */
#define LED_PORT        P1OUT
#define LED_RED         BIT(5)
#define LED_YLW         BIT(6)

/* Port 2 */
#define RFID_IRQ        BIT(0)
#define BB_SSEL_LINE    BIT(2)
#define BB_MOSI_LINE    BIT(3)
#define OMAP_IRQ_LINE   BIT(4)

/* Port 3 */
#define BB_MISO_LINE    BIT(0)
#define BB_DCLK_LINE    BIT(1)
#define TXB0104_REF     BIT(3)
#define UART0_TX        BIT(4) 
#define UART0_RX        BIT(5)

/* Port 4 */

/* Port 5 */
#define RFID_PORT       P5OUT
#define RFID_SSEL       BIT(0)
#define MOSI1           BIT(1) //swapped mosi with miso
#define MISO1           BIT(2)
#define DCLK1           BIT(3)
#define RFID_EN         BIT(4)

#define RFID_LENGTH 5

void panic(void);

void irq_wait(void);
void irq_reset(void);
int irq_is_pending(void);

void rfid_loop(void);

void init_ports(void);


#endif /* _RFID_H */

