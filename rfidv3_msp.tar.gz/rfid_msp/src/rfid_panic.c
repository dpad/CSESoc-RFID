#include "led.h"

void panic(void)
{
	led_ylw(0);
	led_red(1);

	for (;;) {
		led_ylw_toggle();
		led_red_toggle();
		//delay(100000);
        long i = 100000;
        while(i--);
	}
}
