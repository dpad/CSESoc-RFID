#include <string.h>
#include "crypto1.h"
#include "crypto1_mifare.h"
#include "14443.h"

#include "parallel.h"
#include "globals.h"
#include "directmode.h"

static crypto1_state cipher_state;
static crypto1_state * const ch = &cipher_state;
static int cipher_active = 0;

/* Initialize the crypto1 cipher and set a key (6 bytes) */
void MifareSetKeyCommand(unsigned char *pbuf, unsigned char length)
{
  if(!crypto1_new(ch, 0, CRYPTO1_IMPLEMENTATION_CLEAN)) {
    send_cstring("Initialization failed\r\n");
  }
  
  if(length < 6) {
    send_cstring("!! UID too short. Abort\r\n");
    return;
  }
  
  int i=0; uint64emu_storage_t key;
  for(i=0; i<6; i++) {
    uint64emu_setbyte(&key, 5 - i, pbuf[i]);
  }
  crypto1_init(ch, &key);
  if (verbose) send_cstring("Initialization ok\r\n");
}

static parity_data_t auth1_command[4];
static parity_data_t auth1_response[5];

/* Perform first step of authentication (reader side) with given key A or B,
 *  block number and uid */
void MifareAuth1(unsigned char key_select, unsigned char block, unsigned char *_uid, unsigned char length)
{
  auth1_command[0] = key_select;
  auth1_command[1] = block;
  CalculateParity(auth1_command, 2);
  CalculateCRC(auth1_command, 2);
  
  if(length < 4) {
    send_cstring("!! UID too short. Abort\r\n");
    return;
  }
  
  unsigned short recv_bytes = 5;
  unsigned char recv_bits = 0;
  DirectModeTransceive( DIRECT_MODE_SEND_PARITY | DIRECT_MODE_RECV_PARITY,
                       auth1_command, 4, 0,
                       auth1_response, &recv_bytes, &recv_bits);
  if(recv_bytes != 4 || recv_bits != 0) {
    send_cstring("!! ");
    Put_byte(recv_bytes & 0xff); send_cstring(" bytes and ");
    Put_byte(recv_bits); send_cstring(" bits received, expected 4 bytes and 0 bits. Abort\r\n");
    MifareResetCipher();
    return;
  }
  
  if(!CheckParity(auth1_response, 4)) {
    send_cstring("!! Wrong parity on card nonce. Abort\r\n");
    MifareResetCipher();
    return;
  }
  
  uint32_t uid = ARRAY_TO_UINT32(_uid), nonce = ARRAY_TO_UINT32(auth1_response);
  crypto1_mutual_1(ch, uid, nonce);
  if (verbose) {
    send_cstring("Card nonce: ");
    Put_byte(auth1_response[0]);
    Put_byte(auth1_response[1]);
    Put_byte(auth1_response[2]);
    Put_byte(auth1_response[3]);
    send_cstring(". Success\r\n");
  }
}

static parity_data_t auth2_command[8];
static parity_data_t auth2_response[5];

/* Perform second step of authentication (reader side), use given random number
 *  for the reader nonce. */
void MifareAuth2(unsigned char *random, unsigned char length)
{
  if(length < 4) {
    send_cstring("!! Random too short. Abort\r\n");
    MifareResetCipher();
    return;
  }
  
  UINT32_TO_ARRAY_WITH_PARITY( ARRAY_TO_UINT32(random), auth2_command);
  crypto1_mutual_2(ch, auth2_command);
  
  unsigned short recv_bytes = 5;
  unsigned char recv_bits = 0;
  DirectModeTransceive( DIRECT_MODE_SEND_PARITY | DIRECT_MODE_RECV_PARITY,
                       auth2_command, 8, 0,
                       auth2_response, &recv_bytes, &recv_bits);
  if(recv_bytes != 4 || recv_bits != 0) {
    send_cstring("!! ");
    Put_byte(recv_bytes & 0xff); send_cstring(" bytes and ");
    Put_byte(recv_bits); send_cstring(" bits received, expected 4 bytes and 0 bits. Abort2\r\n");
    MifareResetCipher();
    return;
  }
  
  if(!crypto1_mutual_3(ch, auth2_response)) {
    send_cstring("!! Invalid card response. Abort\r\n");
    MifareResetCipher();
    return;
  }
  
  cipher_active = 1;
  LEDspecialON;
  send_cstring("Authentication ok. Success\r\n");
}

void MifareGuessparity(unsigned char * attempts, unsigned char key_select, unsigned char block, unsigned char * uid, unsigned char length) {
  verbose = 0;
  int j;
  char command2[20];
  char uid_copy[5];
  for (j = 0; j < 5; j++) {
    uid_copy[j] = uid[j];
  }
  uint32_t reader_nonce = 12345;

  int nattempts = ARRAY_TO_UINT32(attempts);

  for (j = 0; j < nattempts; j++) {
    LEDspecialTOGGLE;
    discardoutput = 1;
    MifareResetCipher();

    command2[0] = 0x44;
    command2[1] = 0x00;
    command2[2] = 0x00;
    command2[3] = 0xff;
    command2[4] = 0xff;
    command2[5] = 0xff;
    MifareSetKeyCommand(command2, 6);

    char command[4];
    command[0] = ChipStateControl;
    command[1] = 0x01;
    WriteSingle(command, 2);

    command[0] = ChipStateControl;
    command[1] = 0x21;
    command[2] = ISOControl;
    command[3] = 0x88; //08
    WriteSingle(command, 4);
    command[0] = ChipStateControl;
    command[1] = ChipStateControl;
    ReadSingle(command + 1, 1);
    command[1] &= ~BIT2;
    command[1] &= ~BIT3;
    WriteSingle(command, 2);
    command[0] = ChipStateControl;
    command[1] = ChipStateControl;
    ReadSingle(command + 1, 1);
    command[1] &= ~BIT3;
    WriteSingle(command, 2);

    char command2[20];
    command2[5] = 0x26;
    if (RequestCommand(command2, 0x00, 0x0f, 1) == 0) {
      int i;
      for (i = 0; i < 5; i++) {
      	command2[i] = uid_copy[i];
      }
      if (SelectCommand(0x93, command2)) {
	discardoutput = 0;
	verbose = 1;
	send_cstring("\nXXX\n");
	LEDspecialOFF;
	LEDtypeAOFF;
	return;
      } else {

      }
    } else {
      discardoutput = 0;
      verbose = 1;
      send_cstring("\nXXX\n");
      LEDspecialOFF;
      LEDtypeAOFF;
      return;
    }

    MifareAuth1(key_select, block, uid, length);

    reader_nonce += 23;
    UINT32_TO_ARRAY_WITH_PARITY( reader_nonce, auth2_command);
    crypto1_mutual_2(ch, auth2_command);
  
    unsigned short recv_bytes = 5;
    unsigned char recv_bits = 0;
    DirectModeTransceive( DIRECT_MODE_SEND_PARITY | DIRECT_MODE_RECV_PARITY,
			  auth2_command, 8, 0,
			  auth2_response, &recv_bytes, &recv_bits);

    discardoutput = 0;
    if (recv_bytes == 0 && recv_bits == 4) {
      LEDtypeAON
      {
	int i;
	for (i = 0; i < 4; i++) {
	  Put_byte(auth1_response[i]);
	}
      }
      kputchar(' ');
      {
	int i;
	for (i = 0; i < 8; i++) {
	  Put_byte(auth2_command[i] >> 8);
	  Put_byte(auth2_command[i] & 0xff);
	}
      }
      kputchar(' ');
    }
    if (recv_bytes == 0 && recv_bits == 4) {
      Put_byte(auth2_response[0] >> 8);
      Put_byte(auth2_response[0] & 0xff);
      kputchar('\n');
    } else if (recv_bytes == 0 && recv_bits == 0) {
      LEDtypeAOFF
      //      send_cstring("failed\n");
    } else {
      send_cstring("bytes: "); Put_byte(recv_bytes);
      send_cstring("bits: "); Put_byte(recv_bits);
      kputchar('\n');
    }
    discardoutput = 1;
    command[0] = 0x50;
    command[1] = 0x0;
    RequestCommand(command, 2, 0, 0);
  }
  LEDspecialOFF;
  LEDtypeAOFF;
  discardoutput = 0;
  send_cstring("\nXXX\n");
  verbose = 1;
}

static parity_data_t transceive_buffer[19];
/* Host command. Encrypt and transmit given buffer, receive and decrypt response
 *  then print response. Behaves much like RequestCommand() except for the
 *  possibility to send incomplete bytes. Command or Response shall not exceed 
 *  18 bytes (including CRC). Addition: Incomplete received bytes (broken bits)
 *  are printed in a second pair of []. */
void MifareTransceiveCommand(unsigned char *pbuf, unsigned short numbytes, char noCRC)
{
  int i;
  if(!cipher_active) {
    send_cstring("!! cipher not initialized. Abort\r\n");
  }
  
  if( (noCRC && numbytes > 18) || (!noCRC && numbytes > 16) ) {
    send_cstring("!! numbytes too big. Abort\r\n");
    return;
  }
  
  for(i=0; i<numbytes; i++)
    transceive_buffer[i] = pbuf[i];
  CalculateParity(transceive_buffer, numbytes);
  
  if(!noCRC)
    numbytes = CalculateCRC(transceive_buffer, numbytes);
  
  crypto1_transcrypt(ch, transceive_buffer, numbytes);
  
  unsigned short recv_bytes = 19;
  unsigned char recv_bits = 0;
  DirectModeTransceive(DIRECT_MODE_SEND_PARITY | DIRECT_MODE_RECV_PARITY,
                       transceive_buffer, numbytes, 0,
                       transceive_buffer, &recv_bytes, &recv_bits);
  
  crypto1_transcrypt_bits(ch, transceive_buffer, recv_bytes, recv_bits);
  
  if(recv_bytes > 2) {
    if(!CheckParity(transceive_buffer, recv_bytes)) {
      send_cstring("!! parity error. Abort\r\n");
      MifareResetCipher();
      return;
    }
    
    if(!CheckCRC(transceive_buffer, recv_bytes)) {
      send_cstring("!! CRC error. Abort\r\n");
      MifareResetCipher();
      return;
    }
    
    recv_bytes -= 2;
  }
  
  kputchar('[');
  for(i=0; i<recv_bytes; i++) {
    Put_byte(transceive_buffer[i] & 0xff);
  }
  kputchar(']');
  
  if(recv_bits > 0) {
    unsigned char last_byte = transceive_buffer[recv_bytes] & 0xff;
    last_byte &= ~((~0)<<recv_bits);
    kputchar('[');
    Put_byte( last_byte );
    kputchar(']');
  }
  
}

void MifareResetCipher(void)
{
  memset(&cipher_state, 0, sizeof(cipher_state));
  cipher_active = 0;
}
