#ifndef _TRF796x_H
#define _TRF796x_H


enum trf796x_regs {
	/* main control registers */
	TRF796x_REG_STATUS  = 0x00,
	TRF796x_REG_ISOCTRL = 0x01,

	/* protocol sub-setting registers */
	TRF796x_REG_TX_HIGHRATE     = 0x03,
	TRF796x_REG_TXTIMER_H       = 0x04,
	TRF796x_REG_TXTIMER_L       = 0x05,
	TRF796x_REG_TX_PULSELEN     = 0x06,
	TRF796x_REG_RX_NORESPONSE   = 0x07,
	TRF796x_REG_RX_WAITTIME     = 0x08,
	TRF796x_REG_MODULATOR       = 0x09,
	TRF796x_REG_RX_SPECIAL      = 0x0A,

	/* status registers */
	TRF796x_REG_IRQ_STATUS      = 0x0C,
	TRF796x_REG_IRQ_MASK        = 0x0D,
	TRF796x_REG_COLLISION_POS   = 0x0E,
	TRF796x_REG_RSSI_OSC_STATUS = 0x0F,

    TRF796x_CMD_LIST_SIZE = 10,

	/* FIFO registers */
	TRF796x_REG_FIFO_STATUS = 0x1C,
	TRF796x_REG_FIFO_TXLEN1 = 0x1D,
	TRF796x_REG_FIFO_TXLEN2 = 0x1E,
	TRF796x_REG_FIFO_IO     = 0x1F,
};

enum trf796x_isoctrl_bits {
	TRF796x_ISOCTRL_RXCRC = 0x01 << 7,
};

enum trf796x_commands {
	TRF796x_CMD_IDLE           = 0x00,
	TRF796x_CMD_SWINIT         = 0x03,
	TRF796x_CMD_RESET          = 0x0F,
	TRF796x_CMD_XMIT_NOCRC     = 0x10,
	TRF796x_CMD_XMIT_CRC       = 0x11,
	TRF796x_CMD_XMIT_DLY_NOCRC = 0x12,
	TRF796x_CMD_XMIT_DLY_CRC   = 0x13,
	TRF796x_CMD_XMIT_NEXTSLOT  = 0x14,
	TRF796x_CMD_RECVR_DISABLE  = 0x16,
	TRF796x_CMD_RECVR_ENABLE   = 0x17,
	TRF796x_CMD_TEST_INTERNAL  = 0x18,
	TRF796x_CMD_TEST_EXTERNAL  = 0x18,
	TRF796x_CMD_RECVR_GAINADJ  = 0x1A,
};

enum trf796x_command_encoding {
	TRF796x_CONT    = 0x1 << 5,
	TRF796x_READ    = 0x1 << 6,
	TRF796x_WRITE   = 0x0,
	TRF796x_COMMAND = 0x1 << 7,
	TRF796x_ADDRESS = 0x0,

	TRF796x_ADDRESS_MASK = 0x1F,
};

enum trf796x_irqstatus_encoding {
	TRF796x_NORESPONSE = 0x01 << 0,
	TRF796x_COLLISION  = 0x01 << 1,
	TRF796x_FRAMEERR   = 0x01 << 2,
	TRF796x_PARITYERR  = 0x01 << 3,
	TRF796x_CRCERR     = 0x01 << 4,
	TRF796x_FIFOSIG    = 0x01 << 5,
	TRF796x_RXSIG      = 0x01 << 6,
	TRF796x_TXSIG      = 0x01 << 7,
    TRF796x_TXCRC      = 0x01 << 0,
};

enum {
	TRF796x_FIFO_BYTES = 12,
};

enum trf796x_txrx_flags {
	TRF796x_TXRX_NONE    = 0,
	TRF796x_TXRX_RXCRC   = 0x01 << 0,
	TRF796x_TXRX_TXCRC   = 0x01 << 1,
	TRF796x_TXRX_NORETRY = 0x01 << 2,
};

enum trf796x_return_values {
	TRF796x_OK,
	TRF796x_ERR,
	TRF796x_RET_COLL,
	TRF796x_RET_TIMEOUT,
	TRF796x_RET_MAX,
};

enum trf796x_rfid_errors {
    RFID_ERR_TIMEOUT = -1,
    RFID_ERR_NORESPONSE = -2,
    RFID_ERR_COLLISION = -3,
    RFID_ERR_FRAME = -4,
    RFID_ERR_FIFO = -5,
    RFID_ERR_CASCADE0 = -6,
};

int trf796x_init(void);
int trf796x_iso14443a_init(void);
uint8_t trf796x_read_reg(uint8_t reg);
uint8_t trf796x_read_irqstatus(void);
void trf796x_write_reg(uint8_t reg, uint8_t value);
void trf796x_command(uint8_t cmd);
int trf796x_read_fifo(uint8_t *bytes, int more);
uint16_t trf796x_read_collision_pos(void);
int trf796x_set_radio(int state);
int trf796x_block_recvr(void);

int trf796x_readCard(uint8_t *buf, int bufsz);
void trf796x_readCards(void);
int trf796x_getNextUID(uint8_t * buf);

int my_read_card(uint8_t *buf, int bufsize);
uint8_t my_trf796x_read_irqstatus(void);

#define trf796x_enable_radio()  trf796x_set_radio(1)
#define trf796x_disable_radio() trf796x_set_radio(0)

#endif /* _TRF796x_H */

