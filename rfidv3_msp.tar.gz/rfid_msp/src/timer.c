#include <io.h>
#include <signal.h>

#include "rfid.h"
#include "led.h"
#include "timer.h"

static volatile uint64_t us;

interrupt(TIMERA1_VECTOR) time_isr(void)
{
	uint16_t taiv = TAIV;

	if (taiv & TAIV_OVERFLOW) {
		us += 1000000;
		//led_red_toggle();
	}
}

void time_init(void)
{
	us = 0;

	TACCR0 = ACLK_FREQ;

	/* Clear counter, input divider /1, ACLK */
	TACTL = MC_UPTO_CCR0 | TAIE | TACLR | ID_DIV1 | TASSEL_ACLK;
}

void time_sleep_us(uint64_t us)
{
	uint64_t time = time_get_us();

	while (time_get_us() < time + us)
		;
}

/*
 * microseconds since boot (really time_init())
 */
uint64_t time_get_us(void)
{
	uint64_t time;
	uint64_t tar;

	do {
		time = us;
		tar = TAR;
	} while (time != us);

	/* convert tar to microseconds */
	time += (tar * 1000000) >> ACLK_FREQ_LOG2;

	return time;
}

