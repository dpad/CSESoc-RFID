#include <io.h>
#include <signal.h>
#include "spi.h"
#include "rfid.h"
#include "printf.h"

static int spi0_selected_device; 

void spi0_init(void)
{
	spi0_selected_device = DEV_NONE;

	/* disable module, SMCLK clk source */
	UCB1CTL1 = UCSWRST | UCSSEL_SMCLK;

	/* sync (SPI), master, MSB first */
	UCB1CTL0 = UCSYNC | UCMST | UCCKPH | UCMSB;

	/* SMCLK/16 = 1MHz */
	//UCB1BR0 = 0x80;
	//UCB1BR1 = 0x00;
	UCB1BR0 = 0x80;
	UCB1BR1 = 0x00;

	/* no IRQs */
	UC1IE &= ~(UCB1TXIE | UCB1RXIE);
    

	/* enable module */
	UCB1CTL1 &= ~UCSWRST;
}

void spi0_select_device(int device)
{
    //printf("SPI -------------v\n");
	if (spi0_selected_device != DEV_NONE) 
		panic();

	switch (device) { 
	case DEV_TRF796x:  
		ENABLE_TRF796x();
		break; 

	default:
		panic();
	} 

	spi0_selected_device = device; 	 
} 

void spi0_deselect()
{
    //printf("SPI -------------^\n");
	switch (spi0_selected_device) { 
	case DEV_TRF796x:  
		DISABLE_TRF796x();
		break; 

	default:
		panic();
	} 

	spi0_selected_device = DEV_NONE; 
} 


uint8_t last_lsb = 0;

uint8_t spi0_transfer(uint8_t out)
{
	uint8_t	in; 

    
	UCB1TXBUF = out;

	/* wait until TXBUF is empty */
	while ((UC1IFG & UCB1TXIFG) == 0)
		;
	
    

    /* clear RX */
	UC1IFG &= ~UCB1RXIFG;

	/* wait until RXBUF is full */
	while ((UC1IFG & UCB1RXIFG) == 0)
		;



	in = UCB1RXBUF;
    
    //store the LSB of the number being written
    last_lsb = out & BIT(0);

	return in;
}

uint8_t spi0_read(void)
{
	UCB1CTL0 &= ~UCCKPH;

    //During the read, set the MOSI line either high
    //or low depending on the value of the LSB of
    //the last number that was sent.
    int out = 0;
    if (last_lsb) {
        out = 0xFF;
    }

	return spi0_transfer(out);
}

void spi0_write(uint8_t out)
{
	UCB1CTL0 |= UCCKPH;
	(void)spi0_transfer(out);
}


