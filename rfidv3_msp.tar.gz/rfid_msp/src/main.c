#include <io.h>
#include <signal.h>
#include <iomacros.h>
#include <string.h>
#include <msp430x24x1.h>

#include "serial.h"
#include "rfid_print.h"
#include "rfid.h"
#include "spi.h"
#include "timer.h"

#include "bitbanged_spi.h"

int main(void) {
    
    init_clock();
    time_init();
    spi0_init();
    init_ports();
    rfid_print_init();

    eint();

    P2DIR |= BB_MOSI_LINE;
    P2OUT |= BB_MOSI_LINE;
    
    rfid_loop(); 
    
    return 0;
}


