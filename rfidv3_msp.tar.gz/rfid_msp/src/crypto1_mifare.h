#ifndef CRYPTO1_MIFARE_H_
#define CRYPTO1_MIFARE_H_

extern void MifareSetKeyCommand(unsigned char *pbuf, unsigned char length);
extern void MifareAuth1(unsigned char key_select, unsigned char block, unsigned char *uid, unsigned char length);
extern void MifareAuth2(unsigned char *random, unsigned char length);
extern void MifareTransceiveCommand(unsigned char *pbuf, unsigned short numbytes, char noCRC);
extern void MifareResetCipher(void);
extern void MifareGuessparity(unsigned char * attempts, unsigned char key_select, unsigned char block, unsigned char * uid, unsigned char length);

#endif

