#ifndef _TIMER_H
#define _TIMER_H

void time_init(void);
uint64_t time_get_us(void);
void time_sleep_us(uint64_t us);

inline static void time_sleep_ms(uint64_t ms)
{
	return time_sleep_us(ms * 1000);
}

inline static void time_sleep_s(uint64_t s)
{
	return time_sleep_ms(s * 1000);
}

#endif

