#include <io.h>
#include <signal.h>
#include <iomacros.h>
#include <string.h>
#include <msp430x24x1.h>

#include "serial.h"
#include "rfid_print.h"
#include "rfid.h"
#include "bitbanged_spi.h"
#include "timer.h"


void bb_spi_write(uint8_t tx_data) {


    // the clock line doesn't work - using ssel as a clock
        
    while (P2IN & BB_SSEL_LINE);

    //when we are here, the clock has just gone low
    //a write is starting
    int i;
    int mask = BIT(7);


    while ((P2IN & BB_SSEL_LINE) == 0) {
        udelay(1); // not sure why, but this make it more reliable
    }


    while (P2IN & BB_SSEL_LINE);
    
    for (i=0;i<8;i++) {

        if (tx_data & mask) {
            P3OUT |= BB_DCLK_LINE;
        } else {
            P3OUT &= ~BB_DCLK_LINE;
        }

        while ((P2IN & BB_SSEL_LINE) == 0);
        while (P2IN & BB_SSEL_LINE);
        mask = mask >> 1;
    }
    
}


/**
 * spi_transfer_bitbang
 *
 * - Reads one byte from SPI and places it at the given address
 * - Simultaneously writes one byte to SPI
 *
 * - In the event that the SSEL line goes high before the transfer
 *   is complete, 0 is returned and the value in dest remains
 *   unchanged.
 *
 * - The options are provided to wait for the SSEL line to
 *   go low before transfering, and waiting for the SSEL line to
 *   go high before returning (using the pre_wait and
 *   post_wait arguments). These allow for multiple transfers
 *   to be linked without the need for the SSEL line to
 *   go high in between.
 *
 * @param dest a pointer to the destination variable
 *        source the value to send
 *        pre_wait if set, will wait for SSEL to go low
 *                 before starting read
 *        post_wait if set, will wait for SSEL to go high
 *                  before returning
 *
 * @returns 1 if successful read
 */
void spi_transfer_bitbang(uint8_t * dest, uint8_t source, uint8_t pre_wait, uint8_t post_wait) {
    
    uint8_t i;
    uint8_t buffer = 0;
    uint8_t value = 128;
    uint8_t success = 1;
    
    
    //wait for SSEL to be low
    while (pre_wait && BB_SSEL_HI);

    /* Read each bit of the message.
     * Note that the value of BB_MOSI is read
     * on the rising edge of the clock.
     */
    for (i=0;i<8;i++) {

        //wait for clock to be high
        while(BB_DCLK_LO);
        
        //read bit
        if (BB_MOSI) {
            buffer += value;
        }

        //write bit
        if (source & value) {
            BB_MISO_SET;
        } else {
            BB_MISO_CLEAR;
        }
        
        //move to next bit
        value >>= 1;
        
        //wait for clock to be low
        while(BB_DCLK_HI);
        
    }
    

    BB_MISO_CLEAR;
    
    //wait for SSEL to be high
    while (post_wait && BB_SSEL_LO);
    
    //store the byte we just read at the given address
    if (success && dest != NULL) {
        *dest = buffer;
    }
    
}


