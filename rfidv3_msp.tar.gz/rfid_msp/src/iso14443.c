#include "iso14443.h"
#include "stdint.h"

int iso14443_uid_crc(uint8_t buf[5])
{
	return buf[0] == (buf[1]^buf[2]^buf[3]^buf[4]);
}

void iso14443_crcA(uint8_t *buf, unsigned buflen, uint8_t ret[2])
{
	uint16_t val = ISO14443_CRCA_IV;
	uint8_t ch;

	do {
		ch = *buf++;
		ch ^= (uint8_t)(val & 0xFF);
		ch ^= ch << 4;

		val = (val >> 8)
			 ^ ((uint16_t)ch << 8)
			 ^ ((uint16_t)ch << 3)
			 ^ ((uint16_t)ch >> 4);

	} while (--buflen);

	ret[0] = val & 0xFF;
	ret[1] = (val >> 8) & 0xFF;
}

